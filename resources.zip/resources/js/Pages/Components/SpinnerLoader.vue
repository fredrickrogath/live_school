<template>
    <div class="flex h-screen justify-center items-center">
        <div class="text-center text-gray-500">
            <v-progress-circular
                indeterminate
                color="primary"
            ></v-progress-circular>

            <!-- <v-progress-circular
                indeterminate
                color="red"
            ></v-progress-circular>

            <v-progress-circular
                indeterminate
                color="purple"
            ></v-progress-circular>

            <v-progress-circular
                indeterminate
                color="green"
            ></v-progress-circular>

            <v-progress-circular
                indeterminate
                color="amber"
            ></v-progress-circular> -->
        </div>
    </div>
</template>

<style scoped>
.v-progress-circular {
    margin: 1rem;
}
</style>
