export default {
    getTab(state) {
        return state.tab;
    },

    // finalCounter2(_, getters){
    //     // the dash is for the state
    //     return getters.finalCounter;
    // }
};