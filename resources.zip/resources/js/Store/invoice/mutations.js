export default {
    setTab(state, tab) {
        state.tab = tab;
    },
};