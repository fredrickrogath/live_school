export default {
    setTab(context, tab) {
        // for data will be data.value

        context.commit("setTab", tab);
    },
};