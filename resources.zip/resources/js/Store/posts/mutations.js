export default {
    pushPosts(state, data) {
        state.posts.push(data);
    },
};